KALAI · கலை — Camera Studio (prototype v0.1)
See your shot before you shoot it.

HOW TO START
  Double-click Kalai.html. It opens in your browser (Chrome or Edge recommended)
  and runs fully offline. No install, no account, no internet needed.

WHAT YOU CAN DO
  - Add camera moves from the library (18 moves: push in, orbit, dolly zoom, crane...)
  - Shape each shot: lens, shot size, subject, height, angle, speed, easing
  - Watch the camera frame and the set view (top-right) update live
  - Switch between No-code and Code (edit the scene as structured data)
  - Cinematic looks: Golden hour, Teal & orange, Night, Noir, Neutral
  - Real lens behaviour: aperture (f/1.4–f/11) controls background blur
  - Frame for cinema 2.39:1, YouTube 16:9, Reels/Shorts 9:16 or square
  - Export a shot list (.csv), a frame (.png) or a preview video (.webm)
  - Save and open projects (.kalai.json)

LOW-END LAPTOPS
  Kalai switches to Light mode automatically if playback is slow.
  You can also toggle it with the lightning button in the top bar.

PRIVACY
  Kalai never connects to the internet and collects no data.
  Files are only saved where you choose to download them.

© 2026 Kalai. All rights reserved.
